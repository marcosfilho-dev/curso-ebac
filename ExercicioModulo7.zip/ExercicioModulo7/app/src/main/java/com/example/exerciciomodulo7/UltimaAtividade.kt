package com.example.exerciciomodulo7

class UltimaAtividade {
}
// Nessa Atividade consta a atividade 3 e 4
fun main() {
    println(UtilityHelper.isWeekEnd())
    UtilityHelper.setCurrentDay(DayWeek.MONDAY)
    println(UtilityHelper.isWeekEnd())
    UtilityHelper.setCurrentDay(DayWeek.SUNDAY)
    println(UtilityHelper.isWeekEnd())
}
object UtilityHelper {
    private var currentDay: DayWeek = DayWeek.SUNDAY
    init {
        setCurrentDay(DayWeek.SUNDAY)
    }
    fun setCurrentDay(actualDay: DayWeek) {
        this.currentDay = actualDay
    }
    fun isWeekEnd(): Boolean {
        return if (currentDay == DayWeek.SATURDAY || currentDay == DayWeek.SUNDAY) {
            return true
        } else false
    }
}
enum class DayWeek() {
    MONDAY() {
        override val dayOfWeek = "monday"
    },
    TUESDAY() {
        override val dayOfWeek = "tuesday"
    },
    WEDNESDAY() {
        override val dayOfWeek = "wednesday"
    },
    THURSDAY() {
        override val dayOfWeek = "thursday"
    },
    FRIDAY() {
        override val dayOfWeek = "friday"
    },
    SATURDAY() {
        override val dayOfWeek = "saturday"
    },
    SUNDAY() {
        override val dayOfWeek = "sunday"
    };
    abstract val dayOfWeek: String
}