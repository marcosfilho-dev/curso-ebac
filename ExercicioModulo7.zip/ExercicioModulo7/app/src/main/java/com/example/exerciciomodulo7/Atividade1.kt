package com.example.exerciciomodulo7

class Atividade1 {
}

fun main() {
    val word = "casa"
    println(word.stringList())
}
fun String.stringList(): List<Char> {
    return this.toList()
}