package com.example.exerciciomodulo10

import android.app.LauncherActivity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.ViewParent
import androidx.recyclerview.widget.RecyclerView
import com.example.exerciciomodulo10.databinding.ItemBinding

class ListAdapter (
    val listItems : MutableList<ListItem>,
    val listener : ListAdapterListener
        ) : RecyclerView.Adapter<ListAdapter.ListItemViewHolder>(){
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListItemViewHolder {
                return ListItemViewHolder(
                    ItemBinding.inflate(
                        LayoutInflater.from(parent.context),
                        parent, false)
                )
            }

    override fun onBindViewHolder(holder: ListItemViewHolder, position: Int) {
        val item = listItems[position]
        holder.name.text = item.name
        holder.phone.text = item.phone
        holder.root.setOnClickListener {
            listener.onItemClicked(item.name)

        }
    }
    override fun getItemCount(): Int {
        return  listItems.size
    }
    class ListItemViewHolder(binding: ItemBinding) : RecyclerView.ViewHolder(binding.root){
        var root  = binding.root
        var name = binding.name
        var phone = binding.phone

    }
    interface ListAdapterListener{
        fun onItemClicked(content: String);
    }


}