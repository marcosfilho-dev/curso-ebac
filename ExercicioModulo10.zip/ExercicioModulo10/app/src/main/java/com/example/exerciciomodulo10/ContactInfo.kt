package com.example.exerciciomodulo10

data class ListItem(
    val name : String,
    val phone : String
)
