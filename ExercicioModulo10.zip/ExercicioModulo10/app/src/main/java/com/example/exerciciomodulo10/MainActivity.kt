package com.example.exerciciomodulo10

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import com.example.exerciciomodulo10.ListAdapter.ListAdapterListener
import com.example.exerciciomodulo10.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity(),  ListAdapterListener {
    private lateinit var binding: ActivityMainBinding
    private  val itemList : MutableList<ListItem> = mutableListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        createMockData()
        setContentView(binding.root)
        val listView = binding.lista
        listView.layoutManager = LinearLayoutManager(this)
        listView.adapter = ListAdapter(itemList, this)
    }
    fun createMockData(){
        itemList.add(ListItem("Pedro", "(85) 9888888698"))
        itemList.add(ListItem("Marcos", "(85) 9888888888"))
        itemList.add(ListItem("Felipe", "(85) 9889898888"))
        itemList.add(ListItem("Bruna", "(85) 9855558888"))
        itemList.add(ListItem("Pai", "(85) 988795665"))
        itemList.add(ListItem("Tio Paulo", "(85) 9888888888"))
        itemList.add(ListItem("Vó Maria", "(85) 9888888888"))
        itemList.add(ListItem("Cleo", "(85) 9888888888"))
        itemList.add(ListItem("Hospital", "(85) 9888888888"))
        itemList.add(ListItem("Filho", "(85) 9888888888"))
        itemList.add(ListItem("Lucas", "(85) 9888888888"))
        itemList.add(ListItem("Thiago", "(85) 9888888888"))
        itemList.add(ListItem("Pedro novo", "(85) 9888888888"))
        itemList.add(ListItem("Regina", "(85) 9888888888"))
        itemList.add(ListItem("Vô", "(85) 9888888888"))
        itemList.add(ListItem("Luan", "(85) 9888888888"))
        itemList.add(ListItem("Petrick", "(85) 9888888888"))
        itemList.add(ListItem("Pedro", "(85) 9888888888"))
        itemList.add(ListItem("Maria", "(85) 9888888888"))
        itemList.add(ListItem("Ebac", "(85) 9888888888"))
        itemList.add(ListItem("Pedro", "(85) 9888888888"))
        itemList.add(ListItem("José", "(85) 9888888888"))
        itemList.add(ListItem("Pedrinho trabalho", "(85) 9888888888"))
        itemList.add(ListItem("Marcos Claro", "(85) 9888888888"))
        itemList.add(ListItem("Paulo", "(85) 9888888888"))



    }

    override fun onItemClicked(content: String) {
        Snackbar.make(binding.root, content, Snackbar.LENGTH_SHORT).show()
    }

}