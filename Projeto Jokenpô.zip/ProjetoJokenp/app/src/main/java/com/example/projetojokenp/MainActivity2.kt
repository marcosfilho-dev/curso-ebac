package com.example.projetojokenp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.example.projetojokenp.databinding.ActivityMain2Binding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar

class MainActivity2 : AppCompatActivity() {
    lateinit var  drawer: DrawerLayout
    lateinit var navDrawer : NavigationView
    lateinit var bottonNav: BottomNavigationView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain2Binding.inflate(layoutInflater)
        val toolbar = binding.toolbar
        setContentView(binding.root)
        setSupportActionBar(toolbar)

        drawer = binding.root
        navDrawer = binding.navView
        bottonNav = binding.bottonView

        setupToolbar()
        setupDrawer()
        setupBottonNavigation()

    }
    private fun setupBottonNavigation(){
        bottonNav.setOnItemSelectedListener {
                menuItem -> when(menuItem.itemId){
            R.id.bottom_option_1 -> {
                startActivity(Intent(this,MainActivity2::class.java))
                Snackbar.make(drawer,getString(R.string.jogador_1),Snackbar.LENGTH_SHORT).show()
                true
            }
            R.id.bottom_option_2 -> {
                // Vai mostrar que a tela foi criar
                startActivity(Intent(this,MainActivity3::class.java))
                true
            }
            else -> false
        }
        }
    }
    private fun setupDrawer(){
        navDrawer.setNavigationItemSelectedListener {
                menuItem ->
            drawer.closeDrawers()
            when(menuItem.itemId){
                R.id.drawer_jogador -> {
                   startActivity(Intent(this,MainActivity2::class.java))

                    //val intent = Intent(this, MainActivity:: class.java)
                    //startActivity(intent)
                    true
                }
                R.id.drawer_resultado ->{
                    // Vai mostrar que a tela foi criar
                    startActivity(Intent(this,MainActivity3::class.java))
                    true
                }
                else -> false
            }

        }
    }
    private fun setupToolbar(){
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_menu)
    }
    override fun onSupportNavigateUp(): Boolean {
        drawer.openDrawer(GravityCompat.START)
        return true
    }
    //O menu não está sendo mostrado na toolbar
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater : MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_toolbar,menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.menu_reniciar-> {
                // Aqui está mostrando que está a funcionar
                Snackbar.make(this,drawer, getString(R.string.reniciar), Snackbar.LENGTH_SHORT).show()
                true
            }

            else -> false
        }
    }

}