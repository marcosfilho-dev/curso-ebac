package com.example.exerciciomodulo8

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat

class MainActivity : AppCompatActivity() {
    var button : Button? = null
    var textTitlo : TextView? = null
    var editText : EditText? = null
    var numClicks : Int = 1
    var tela : LinearLayoutCompat? = null

    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textTitlo = findViewById(R.id.titulo)
        editText = findViewById(R.id.inputText)
        button = findViewById(R.id.buttonAcao)
        tela = findViewById(R.id.tela)

        button?.setOnClickListener {
            clickButton()
            numClicks++
            textTitlo?.setTextColor(getResources().getColor(R.color.white))
            editText?.setTextColor(getResources().getColor(R.color.white))
            editText?.setHintTextColor(getResources().getColor(R.color.white))
            when{
                numClicks % 2 == 0 -> tela?.setBackgroundResource(R.drawable.james)
                numClicks % 3 == 0 -> tela?.setBackgroundResource(R.drawable.nebulosa)
                else -> tela?.setBackgroundResource(R.drawable.terra)
            }
        }
    }
    fun clickButton(){
        textTitlo?.text = "${editText?.text} você clicou ${numClicks} no botão!!"
    }
}