package com.example.exerciciomodulo3

class Exercicio3 {
}

fun main() {// Exercicio do ultimo slide \\
    // Array de 40 posiçôes \\
    var array: IntArray = IntArray(40  - 1)
    var i = 0
    for (i in array.indices){
        array[i] = i + 1
        println(array[i])



    }
    // Array de 99 posições \\
    var array2: IntArray = IntArray(99)
    for (i in array2.indices){
        array2[i] = i + 1
        println(array2[i])
    }
    // Soma do array\\
    var  soma: Int = 0

    while (i < array2.size){
        soma = soma + array2[i]
        i++
    }
    println(soma)
}