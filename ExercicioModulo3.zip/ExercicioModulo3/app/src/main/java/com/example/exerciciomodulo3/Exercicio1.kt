package com.example.exerciciomodulo3

class Exercicio1 {
}

fun main() { // Exercicio do primeiro slide \\
    // variavel mutavel \\
    var mutavel = 6
    mutavel = 5
    println(mutavel)

    // Variavel mudará de valor pois ela e mutavel

    // variavel imutavel \\
    val imutavel = 6
    //imutavel = 7
    println(imutavel)
    // Nesse código apresenta erro pois variaveis imutanveis(val) não podem ser alteradas
}