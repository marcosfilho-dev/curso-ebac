package com.example.exerciciomodulo3

class Exercicio2 {
}

fun main() { // Exercicio do segundo slide \\
    // Número par \\
    var par = 4
    var impar = 9
    if (par % 2 == 0)
        println(" O número é par!")
        else println("O número é impar")
    // Número impar \\
    if (impar % 2 == 1)
        println(" O número é impar!")
        else println("O número é par")

    // Utilizando o when \\

    // número par \\
     var numeropar = when{
        par  % 2 ==0 ->(" O número é par!")
        else ->("O numero é impar")

    }
    println(numeropar)
    // Número impar \\
    var numeroimpar = when{
        impar % 2 == 1 -> (" O número é impar!")
        else -> ("O número é par")
    }
    println(numeroimpar)
}