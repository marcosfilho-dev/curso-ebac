package com.example.exerciciomodulo5


class Exercicio {
}

fun main() {
    var veiculo = Veiculo("Tesla")
    // aceleração do veiculo
    veiculo.aceleracao(100)
    // imprimindo a velocidade
    veiculo.print()
    // reducao da velecidde do veiculo
    veiculo.reduzir(50)
    veiculo.print()

}
class Veiculo(model: String){
    private var velocity: Int
    private var acceleration: Int
    var model: String

    init {
        this.model = model
        this.velocity = 0
        this.acceleration = 10

    }
    fun aceleracao(amount: Int) {
        velocity = acceleration + amount

    }
    fun reduzir(amount: Int): Int{
        velocity -= amount
        if (velocity < 0)
            velocity = 0
        return velocity
    }
    fun print(){
        println(" Modelo: $model, Velocidade: $velocity")
    }

}