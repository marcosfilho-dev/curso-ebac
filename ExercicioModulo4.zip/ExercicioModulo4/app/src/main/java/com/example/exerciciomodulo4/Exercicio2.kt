package com.example.exerciciomodulo4

class Exercicio2 {
}

fun main() {
    val resultado = multipicacao(9, 8)
    println(resultado)
}
fun multipicacao (number1: Int, number2: Int) : Int = number1 * number2