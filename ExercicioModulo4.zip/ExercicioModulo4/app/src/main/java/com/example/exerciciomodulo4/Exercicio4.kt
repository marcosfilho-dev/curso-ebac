package com.example.exerciciomodulo4

class Exercicio4 {
}
// Lista de 99 numeros \\
fun main() {
    val listnumber: IntArray = IntArray(99)
    for (i in listnumber.indices){
        listnumber[i] = i + 1


    }
    val filtered=listnumber.filter{it% 2 == 0}
    println(filtered)

    // Lista nomes
    val nomesList=listOf("marcos","Lucas","Tadeu","Eduardo")
    nomesList.map{"Olá $it"}
        .forEach{
        println(it)
    }
}