package com.example.exerciciomodulo4

class Exercicio3 {
}

fun main() {
calculadora(8,9, ::soma2)
    calculadora(8,9, ::multiplicacao)
}
fun multiplicacao (number1: Int, number2: Int) = println(number1 * number2)
fun soma2 (number1: Int, number2: Int) =  println(number1 + number2)

fun calculadora (number1: Int, number2: Int , operation: (Int, Int )-> Unit){
    operation(number1, number2)
}