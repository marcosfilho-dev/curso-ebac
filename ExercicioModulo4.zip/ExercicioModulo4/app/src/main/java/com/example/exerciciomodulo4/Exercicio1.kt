package com.example.exerciciomodulo4

class Exercicio1 {
}

fun main() {
    soma(9, 8)

}
fun soma (number1: Int, number2: Int){
    println(number1 + number2)
}