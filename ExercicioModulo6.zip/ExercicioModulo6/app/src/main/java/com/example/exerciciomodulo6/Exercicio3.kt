package com.example.exerciciomodulo6

class Exercicio3 {
}

fun main() {
    val factory = VeiculoFactory()
    val veiculoList : MutableList<Veiculo> = mutableListOf()

    for (i in 1 .. 20){
        val  veiculo = factory.createVeiculo(type = i % 2)
        veiculoList.add(veiculo)
    }


    veiculoList.forEach {
        veiculo ->
        veiculo.aceleracao()
        println(veiculo)

    }

}
abstract class Veiculo() {
    abstract var velocity: Int
    abstract var acceleration: Int
    abstract var model: String

    abstract fun aceleracao()

    override fun toString() = "model: ${model} velocidade ${velocity}"

}


class VeiculoFactory{
    fun createVeiculo(type: Int): Veiculo{
        return when(type){
            1 -> Carro()
            else -> Moto()
        }
    }

}
class Carro() : Veiculo() {
    override var model: String = "Fiat"
    override var velocity: Int = 0
    override var acceleration: Int = 5

    override fun aceleracao() {
       this.velocity = acceleration + velocity

    }


}
 class Moto() : Veiculo() {
    override var model: String = "Honda"
     override var velocity: Int = 0
    override var acceleration: Int = 50


     override fun aceleracao() {
         this.velocity = acceleration + velocity++
     }

}