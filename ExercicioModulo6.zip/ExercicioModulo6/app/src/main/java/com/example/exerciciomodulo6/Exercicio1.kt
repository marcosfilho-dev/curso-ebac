package com.example.exerciciomodulo6

class Exercicio1 {
}
/*
fun main() {
    var carro = Carro()
    carro.model = "Fiat Palio"
    println(carro.aceleracao(0))
    println(carro.print())

    var moto = Moto()
    moto.model = "Honda Fan"
    println(moto.aceleracao(5))
    println(moto.print())

}
class Carro : Veiculo(){
    override var model = ""
    override var acceleration = 0
    override var velocity = 0

    override fun aceleracao(amount: Int) {
        velocity = acceleration + amount
    }

    override fun reduzir(amount: Int): Int {
        velocity -= amount
        if (velocity < 0)
            velocity = 0
        return velocity
    }
    override fun print(){
        println(" Modelo: $model, Velocidade: $velocity")
    }
}
class Moto : Veiculo(){
    override var model = ""
    override var acceleration = 0
    override var velocity = 0

    override fun aceleracao(amount: Int) {
        velocity = acceleration + amount
    }

    override fun reduzir(amount: Int): Int {
        velocity -= amount
        if (velocity < 0)
            velocity = 0
        return velocity
    }
    override fun print(){
        println(" Modelo: $model, Velocidade: $velocity")
    }
}
abstract class Veiculo(){
   abstract var velocity: Int
    abstract var acceleration: Int
    abstract var model: String

    abstract fun aceleracao(amount: Int)
    abstract fun reduzir(amount: Int): Int

    abstract fun print()

}
.*/